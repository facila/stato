#!/bin/bash

ping $1 -c1 -w5 2> /dev/null | grep packets.transmitted | cut -f4 -d' ' 2> /dev/null
