#!/bin/bash

snmpget -Oqv $* .1.3.6.1.2.1.1.5.0 2> /dev/null
